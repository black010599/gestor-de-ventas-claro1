import React, { useState } from 'react';
import { supabase } from '../utils/supabase';
import { motion } from 'framer-motion';
import { LogIn, UserPlus } from 'lucide-react';

const Auth = ({ onLogin }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('vendedor');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const handleAuth = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');

    if (isRegistering) {
      const { data, error: authError } = await supabase.from('users').insert([
        { username, password, role }
      ]);

      if (authError) {
        setError(authError.message);
      } else {
        setMessage('Usuario registrado exitosamente. Ahora puedes iniciar sesión.');
        setUsername('');
        setPassword('');
        setRole('vendedor');
      }
    } else {
      const { data: users, error: authError } = await supabase
        .from('users')
        .select('*')
        .eq('username', username)
        .eq('password', password)
        .single();

      if (authError || !users) {
        setError('Credenciales inválidas. Inténtalo de nuevo, ¡o regístrate si eres nuevo!');
      } else {
        onLogin(users);
      }
    }
  };

  return (
    <motion.div
      className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      <motion.div
        className="bg-white/90 backdrop-blur-xl border border-gray-200/50 rounded-3xl p-8 shadow-xl w-full max-w-md"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 100, damping: 10 }}
      >
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">
          {isRegistering ? 'Registro de Usuario' : 'Inicio de Sesión'}
        </h2>
        <form onSubmit={handleAuth} className="space-y-5">
          <div>
            <label className="block text-gray-700 text-sm font-medium mb-2">Usuario:</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all duration-200"
              placeholder="Tu nombre de usuario"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 text-sm font-medium mb-2">Contraseña:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all duration-200"
              placeholder="Tu contraseña secreta"
              required
            />
          </div>
          {isRegistering && (
            <div>
              <label className="block text-gray-700 text-sm font-medium mb-2">Rol:</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all duration-200 bg-white"
              >
                <option value="vendedor">Vendedor</option>
                <option value="supervisor">Supervisor</option>
              </select>
            </div>
          )}

          {error && (
            <motion.p
              className="text-red-600 text-sm text-center bg-red-100 border border-red-200 rounded-lg p-3"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {error}
            </motion.p>
          )}
          {message && (
            <motion.p
              className="text-green-600 text-sm text-center bg-green-100 border border-green-200 rounded-lg p-3"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {message}
            </motion.p>
          )}

          <motion.button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {isRegistering ? <UserPlus className="w-5 h-5" /> : <LogIn className="w-5 h-5" />}
            {isRegistering ? 'Registrarse' : 'Iniciar Sesión'}
          </motion.button>
        </form>
        <p className="text-center text-gray-600 mt-6">
          {isRegistering ? '¿Ya tienes una cuenta?' : '¿No tienes una cuenta?'}
          <motion.button
            onClick={() => setIsRegistering(!isRegistering)}
            className="text-blue-600 font-semibold ml-2 hover:underline"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isRegistering ? 'Inicia Sesión' : 'Regístrate aquí'}
          </motion.button>
        </p>
      </motion.div>
    </motion.div>
  );
};

export default Auth;