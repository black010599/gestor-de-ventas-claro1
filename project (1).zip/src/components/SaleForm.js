import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '../utils/supabase';
import { PlusCircle, Clipboard, XCircle } from 'lucide-react';
import { parseSaleTemplate } from '../utils/helpers';

const SaleForm = ({ user }) => {
  const [formData, setFormData] = useState({
    client_name: '',
    client_id_card: '',
    client_phone: '',
    province: '',
    canton: '',
    district: '',
    installation_order: '',
    form_number: '',
    sale_date: new Date().toISOString().split('T')[0],
    contracted_plan: '',
    service_type: 'internet', // Default service type
    advisor_id: '', // Now always a select, so initialize empty
    sales_zone_id: '',
    sim: ''
  });
  const [advisors, setAdvisors] = useState([]);
  const [salesZones, setSalesZones] = useState([]);
  const [templateText, setTemplateText] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    fetchAdvisorsAndZones();
  }, []); // No longer dependent on user, fetches once

  const fetchAdvisorsAndZones = async () => {
    setLoadingData(true);
    setError('');
    try {
      const { data: advisorsData, error: advisorsError } = await supabase
        .from('advisors')
        .select('*');
      if (advisorsError) throw advisorsError;
      setAdvisors(advisorsData);

      const { data: zonesData, error: zonesError } = await supabase
        .from('sales_zones')
        .select('*');
      if (zonesError) throw zonesError;
      setSalesZones(zonesData);

    } catch (err) {
      console.error('Error fetching advisors or zones:', err);
      setError('Error al cargar datos para el formulario: ' + err.message);
    } finally {
      setLoadingData(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handlePasteTemplate = () => {
    setError('');
    setMessage('');
    try {
      const parsedData = parseSaleTemplate(templateText);
      
      // Map parsed advisor name to advisor_id
      let advisorIdFromTemplate = '';
      if (parsedData.advisor_name) {
        const advisor = advisors.find(a => a.name.toLowerCase() === parsedData.advisor_name.toLowerCase());
        if (advisor) {
          advisorIdFromTemplate = advisor.id;
        } else {
          setError('Vendedor en la plantilla no encontrado en la base de datos. Por favor, selecciona uno manualmente.');
        }
      }
      parsedData.advisor_id = advisorIdFromTemplate; // Assign advisor_id from template or empty

      // Map parsed sales zone name to sales_zone_id
      let salesZoneIdFromTemplate = '';
      if (parsedData.sales_zone_name) {
        const salesZone = salesZones.find(z => z.name.toLowerCase() === parsedData.sales_zone_name.toLowerCase());
        if (salesZone) {
          salesZoneIdFromTemplate = salesZone.id;
        } else {
          setError('Zona de venta en la plantilla no encontrada en la base de datos. Por favor, selecciona una manualmente.');
        }
      }
      parsedData.sales_zone_id = salesZoneIdFromTemplate;

      // Ensure sale_date is in YYYY-MM-DD format
      if (parsedData.sale_date) {
        const dateParts = parsedData.sale_date.split('/'); // Assuming DD/MM/YY or DD/MM/YYYY
        if (dateParts.length === 3) {
          const day = dateParts[0];
          const month = dateParts[1];
          let year = dateParts[2];
          if (year.length === 2) { // Handle YY format, assume 20YY
            year = `20${year}`;
          }
          parsedData.sale_date = `${year}-${month}-${day}`;
        }
      }

      // Remove non-db fields from parsedData before setting formData
      delete parsedData.advisor_name;
      delete parsedData.sales_zone_name;

      setFormData(prev => ({ ...prev, ...parsedData }));
      setMessage('Datos de la plantilla cargados exitosamente. Revisa y guarda.');
      setTemplateText(''); // Clear template text area
    } catch (err) {
      console.error('Error parsing template:', err);
      setError('Error al procesar la plantilla. Asegúrate de que el formato sea correcto.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');

    // Basic validation
    const requiredFields = [
      'client_name', 'client_id_card', 'client_phone', 'province', 'canton',
      'district', 'installation_order', 'form_number', 'sale_date',
      'contracted_plan', 'service_type', 'advisor_id', 'sales_zone_id' // advisor_id is now always required
    ];
    for (const field of requiredFields) {
      if (!formData[field]) {
        setError(`El campo "${field.replace(/_/g, ' ')}" es obligatorio.`);
        return;
      }
    }

    // Prepare data for insertion: ensure correct types and remove non-db fields
    const dataToInsert = {
      client_name: formData.client_name,
      client_id_card: formData.client_id_card,
      client_phone: formData.client_phone,
      province: formData.province,
      canton: formData.canton,
      district: formData.district,
      installation_order: formData.installation_order,
      form_number: formData.form_number,
      sale_date: formData.sale_date,
      contracted_plan: formData.contracted_plan,
      service_type: formData.service_type,
      advisor_id: formData.advisor_id, // Use the selected advisor_id
      sales_zone_id: formData.sales_zone_id,
      sim: formData.sim // 'sim' is optional, will be null if empty
    };

    try {
      const { data, error: insertError } = await supabase
        .from('sales')
        .insert([dataToInsert])
        .select()
        .single();

      if (insertError) throw insertError;

      setMessage('Venta registrada exitosamente. ¡A seguir vendiendo!');
      setFormData({
        client_name: '',
        client_id_card: '',
        client_phone: '',
        province: '',
        canton: '',
        district: '',
        installation_order: '',
        form_number: '',
        sale_date: new Date().toISOString().split('T')[0],
        contracted_plan: '',
        service_type: 'internet',
        advisor_id: '', // Reset to empty for next entry
        sales_zone_id: '',
        sim: ''
      });
    } catch (err) {
      console.error('Error adding sale:', err);
      setError('Error al registrar la venta: ' + err.message);
    }
  };

  if (loadingData) return <div className="text-center text-gray-600">Cargando formulario de ventas...</div>;
  if (error && !message) return <div className="text-center text-red-600">{error}</div>; 

  return (
    <motion.div
      className="p-8 bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
        <PlusCircle className="w-7 h-7 text-blue-600" /> Registrar Nueva Venta
      </h2>

      {error && (
        <motion.p
          className="text-red-600 text-sm text-center bg-red-100 border border-red-200 rounded-lg p-3 mb-4"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {error}
        </motion.p>
      )}
      {message && (
        <motion.p
          className="text-green-600 text-sm text-center bg-green-100 border border-green-200 rounded-lg p-3 mb-4"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {message}
        </motion.p>
      )}

      <motion.div
        className="bg-gray-50/80 border border-gray-200 rounded-2xl p-6 shadow-md mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
      >
        <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
          <Clipboard className="w-5 h-5 text-purple-500" /> Pegar Plantilla de Venta
        </h3>
        <textarea
          className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500/30 transition-all duration-200 text-gray-900 placeholder-gray-500 font-medium"
          rows="7"
          placeholder="Pega aquí la plantilla de venta (Nombre: ..., Cédula: ..., etc.)"
          value={templateText}
          onChange={(e) => setTemplateText(e.target.value)}
        ></textarea>
        <motion.button
          onClick={handlePasteTemplate}
          className="mt-4 w-full bg-purple-500 text-white py-3 rounded-xl font-semibold shadow-md hover:bg-purple-600 transition-all duration-300 flex items-center justify-center gap-2"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Clipboard className="w-5 h-5" />
          Cargar Datos de Plantilla
        </motion.button>
      </motion.div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Client Info */}
        <motion.div
          className="bg-gray-50/80 border border-gray-200 rounded-2xl p-6 shadow-md"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <h3 className="text-lg font-bold text-gray-800 mb-4">Datos del Cliente</h3>
          <div className="space-y-4">
            <input type="text" name="client_name" placeholder="Nombre del Cliente" value={formData.client_name} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
            <input type="text" name="client_id_card" placeholder="Cédula" value={formData.client_id_card} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
            <input type="text" name="client_phone" placeholder="Teléfono" value={formData.client_phone} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
            <input type="text" name="province" placeholder="Provincia" value={formData.province} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
            <input type="text" name="canton" placeholder="Cantón" value={formData.canton} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
            <input type="text" name="district" placeholder="Distrito" value={formData.district} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
          </div>
        </motion.div>

        {/* Sale Details */}
        <motion.div
          className="bg-gray-50/80 border border-gray-200 rounded-2xl p-6 shadow-md"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <h3 className="text-lg font-bold text-gray-800 mb-4">Detalles de la Venta</h3>
          <div className="space-y-4">
            <input type="text" name="installation_order" placeholder="Orden de Instalación" value={formData.installation_order} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
            <input type="text" name="form_number" placeholder="Número de Formulario" value={formData.form_number} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
            <input type="date" name="sale_date" placeholder="Fecha de Venta" value={formData.sale_date} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
            <input type="text" name="contracted_plan" placeholder="Plan Contratado" value={formData.contracted_plan} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" required />
            
            <div>
              <label className="block text-gray-700 text-sm font-medium mb-2">Tipo de Servicio:</label>
              <select name="service_type" value={formData.service_type} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 bg-white" required>
                <option value="internet">Internet</option>
                <option value="doble play">Doble Play</option>
                <option value="full claro">Full Claro</option>
                <option value="1 play">1 Play</option>
              </select>
            </div>

            <div>
              <label className="block text-gray-700 text-sm font-medium mb-2">Vendedor:</label>
              <select name="advisor_id" value={formData.advisor_id} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 bg-white" required>
                <option value="">Selecciona un vendedor</option>
                {advisors.map(advisor => (
                  <option key={advisor.id} value={advisor.id}>{advisor.name}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-gray-700 text-sm font-medium mb-2">Zona de Venta:</label>
              <select name="sales_zone_id" value={formData.sales_zone_id} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 bg-white" required>
                <option value="">Selecciona una zona</option>
                {salesZones.map(zone => (
                  <option key={zone.id} value={zone.id}>{zone.name}</option>
                ))}
              </select>
            </div>
            <input type="text" name="sim" placeholder="SIM (Opcional)" value={formData.sim} onChange={handleChange} className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30" />
          </div>
        </motion.div>

        <motion.button
          type="submit"
          className="md:col-span-2 w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 mt-4"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <PlusCircle className="w-5 h-5" />
          Guardar Venta
        </motion.button>
      </form>
    </motion.div>
  );
};

export default SaleForm;