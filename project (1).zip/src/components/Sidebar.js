import React from 'react';
import { motion } from 'framer-motion';
import { Home, PlusCircle, Users, LogOut, BarChart2, List } from 'lucide-react';

const Sidebar = ({ user, onNavigate, onLogout, activeTab }) => {
  const navItems = [
    { id: 'dashboard', label: 'Tablero Principal', icon: Home, roles: ['vendedor', 'supervisor'] },
    { id: 'add-sale', label: 'Registrar Venta', icon: PlusCircle, roles: ['vendedor', 'supervisor'] },
    { id: 'sales-list', label: 'Lista de Ventas', icon: List, roles: ['vendedor', 'supervisor'] }, // Now visible for all
    { id: 'advisor-management', label: 'Gestión de Asesores', icon: Users, roles: ['supervisor'] },
  ];

  return (
    <motion.div
      className="w-64 bg-white/90 backdrop-blur-xl border-r border-gray-200/50 p-6 flex flex-col shadow-lg rounded-r-3xl"
      initial={{ x: -200 }}
      animate={{ x: 0 }}
      transition={{ type: "spring", stiffness: 100 }}
    >
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-700 bg-clip-text text-transparent">
          SalesFlow
        </h1>
        <p className="text-sm text-gray-500 mt-1">Bienvenido, {user.username} ({user.role})</p>
      </div>

      <nav className="flex-1 space-y-3">
        {navItems.map((item) => (
          item.roles.includes(user.role) && (
            <motion.button
              key={item.id} // Simplified key, as "Mis Ventas" vs "Todas las Ventas" is now just "Lista de Ventas"
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all duration-200 ${
                activeTab === item.id
                  ? 'bg-blue-500 text-white shadow-md'
                  : 'text-gray-700 hover:bg-gray-100 hover:text-blue-600'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </motion.button>
          )
        ))}
      </nav>

      <motion.button
        onClick={onLogout}
        className="mt-8 w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium bg-red-500 text-white shadow-md hover:bg-red-600 transition-all duration-200"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        <LogOut className="w-5 h-5" />
        Cerrar Sesión
      </motion.button>
    </motion.div>
  );
};

export default Sidebar;