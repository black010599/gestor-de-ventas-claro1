import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '../utils/supabase';
import { BarChart2, Users, DollarSign, MapPin, Calendar, FileText } from 'lucide-react';
import { exportToExcel } from '../utils/helpers';

const Dashboard = ({ user }) => {
  const [totalSales, setTotalSales] = useState(0);
  const [salesByAdvisor, setSalesByAdvisor] = useState([]);
  const [salesByZone, setSalesByZone] = useState([]);
  const [salesByService, setSalesByService] = useState([]);
  const [filterPeriod, setFilterPeriod] = useState('day');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDashboardData();
  }, [filterPeriod, startDate, endDate]);

  const fetchDashboardData = async () => {
    setLoading(true);
    setError('');
    try {
      let query = supabase.from('sales').select(`
        *,
        advisors (name),
        sales_zones (name)
      `);

      const today = new Date();
      let start = new Date();
      let end = new Date();

      if (filterPeriod === 'day') {
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);
      } else if (filterPeriod === 'week') {
        start.setDate(today.getDate() - today.getDay()); // Start of the week (Sunday)
        start.setHours(0, 0, 0, 0);
        end.setDate(start.getDate() + 6); // End of the week (Saturday)
        end.setHours(23, 59, 59, 999);
      } else if (filterPeriod === 'fortnight') {
        const dayOfMonth = today.getDate();
        if (dayOfMonth <= 15) {
          start.setDate(1);
          end.setDate(15);
        } else {
          start.setDate(16);
          end.setMonth(today.getMonth() + 1, 0); // Last day of current month
        }
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);
      } else if (filterPeriod === 'month') {
        start.setDate(1);
        start.setHours(0, 0, 0, 0);
        end.setMonth(today.getMonth() + 1, 0); // Last day of current month
        end.setHours(23, 59, 59, 999);
      } else if (filterPeriod === 'custom' && startDate && endDate) {
        start = new Date(startDate);
        end = new Date(endDate);
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);
      }

      query = query.gte('sale_date', start.toISOString().split('T')[0]);
      query = query.lte('sale_date', end.toISOString().split('T')[0]);

      const { data: salesData, error: salesError } = await query;

      if (salesError) throw salesError;

      setTotalSales(salesData.length);

      const advisorSales = salesData.reduce((acc, sale) => {
        const advisorName = sale.advisors?.name || 'Desconocido';
        acc[advisorName] = (acc[advisorName] || 0) + 1;
        return acc;
      }, {});
      setSalesByAdvisor(Object.entries(advisorSales).map(([name, count]) => ({ name, count })));

      const zoneSales = salesData.reduce((acc, sale) => {
        const zoneName = sale.sales_zones?.name || 'Desconocida';
        acc[zoneName] = (acc[zoneName] || 0) + 1;
        return acc;
      }, {});
      setSalesByZone(Object.entries(zoneSales).map(([name, count]) => ({ name, count })));

      const serviceSales = salesData.reduce((acc, sale) => {
        const serviceType = sale.service_type || 'Desconocido';
        acc[serviceType] = (acc[serviceType] || 0) + 1;
        return acc;
      }, {});
      setSalesByService(Object.entries(serviceSales).map(([type, count]) => ({ type, count })));

    } catch (err) {
      console.error('Error fetching dashboard data:', err);
      setError('Error al cargar los datos del tablero: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      let query = supabase.from('sales').select(`
        client_name, client_id_card, client_phone, province, canton, district,
        installation_order, form_number, sale_date, contracted_plan, service_type,
        advisors (name), sales_zones (name)
      `);

      const today = new Date();
      let start = new Date();
      let end = new Date();
      let fileName = 'Reporte_Ventas';

      if (filterPeriod === 'day') {
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);
        fileName += `_Dia_${start.toISOString().split('T')[0]}`;
      } else if (filterPeriod === 'week') {
        start.setDate(today.getDate() - today.getDay());
        start.setHours(0, 0, 0, 0);
        end.setDate(start.getDate() + 6);
        end.setHours(23, 59, 59, 999);
        fileName += `_Semana_${start.toISOString().split('T')[0]}`;
      } else if (filterPeriod === 'fortnight') {
        const dayOfMonth = today.getDate();
        if (dayOfMonth <= 15) {
          start.setDate(1);
          end.setDate(15);
        } else {
          start.setDate(16);
          end.setMonth(today.getMonth() + 1, 0);
        }
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);
        fileName += `_Quincena_${start.toISOString().split('T')[0]}`;
      } else if (filterPeriod === 'month') {
        start.setDate(1);
        start.setHours(0, 0, 0, 0);
        end.setMonth(today.getMonth() + 1, 0);
        end.setHours(23, 59, 59, 999);
        fileName += `_Mes_${start.toISOString().split('T')[0].substring(0, 7)}`;
      } else if (filterPeriod === 'custom' && startDate && endDate) {
        start = new Date(startDate);
        end = new Date(endDate);
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);
        fileName += `_Desde_${startDate}_Hasta_${endDate}`;
      }

      query = query.gte('sale_date', start.toISOString().split('T')[0]);
      query = query.lte('sale_date', end.toISOString().split('T')[0]);

      const { data: salesToExport, error: exportError } = await query;

      if (exportError) throw exportError;

      const formattedData = salesToExport.map(sale => ({
        'Nombre Cliente': sale.client_name,
        'Cédula Cliente': sale.client_id_card,
        'Teléfono Cliente': sale.client_phone,
        'Provincia': sale.province,
        'Cantón': sale.canton,
        'Distrito': sale.district,
        'Orden de Instalación': sale.installation_order,
        'Número de Formulario': sale.form_number,
        'Fecha de Venta': sale.sale_date,
        'Plan Contratado': sale.contracted_plan,
        'Tipo de Servicio': sale.service_type,
        'Vendedor': sale.advisors?.name || 'Desconocido',
        'Zona de Venta': sale.sales_zones?.name || 'Desconocida',
      }));

      exportToExcel(formattedData, fileName);
    } catch (err) {
      console.error('Error exporting data:', err);
      setError('Error al exportar los datos: ' + err.message);
    }
  };

  if (loading) return <div className="text-center text-gray-600">Cargando datos del tablero...</div>;
  if (error) return <div className="text-center text-red-600">{error}</div>;

  return (
    <motion.div
      className="p-8 bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
        <BarChart2 className="w-7 h-7 text-blue-600" /> Tablero Principal
      </h2>

      <div className="mb-6 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-gray-600" />
          <label htmlFor="filterPeriod" className="text-gray-700 font-medium">Filtrar por:</label>
          <select
            id="filterPeriod"
            value={filterPeriod}
            onChange={(e) => setFilterPeriod(e.target.value)}
            className="px-3 py-2 rounded-xl border border-gray-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
          >
            <option value="day">Día</option>
            <option value="week">Semana</option>
            <option value="fortnight">Quincena</option>
            <option value="month">Mes</option>
            <option value="custom">Rango Personalizado</option>
          </select>
        </div>

        {filterPeriod === 'custom' && (
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-3 py-2 rounded-xl border border-gray-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            />
            <span className="text-gray-600">-</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-3 py-2 rounded-xl border border-gray-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            />
          </div>
        )}

        <motion.button
          onClick={handleExport}
          className="ml-auto bg-green-500 text-white px-5 py-2 rounded-xl font-semibold shadow-md hover:bg-green-600 transition-all duration-300 flex items-center gap-2"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <FileText className="w-5 h-5" />
          Exportar a Excel
        </motion.button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <motion.div
          className="bg-blue-500 text-white rounded-2xl p-6 shadow-lg flex items-center justify-between"
          whileHover={{ scale: 1.03 }}
          transition={{ type: "spring", stiffness: 400, damping: 10 }}
        >
          <div>
            <p className="text-sm font-medium opacity-80">Ventas Totales</p>
            <h3 className="text-4xl font-bold mt-1">{totalSales}</h3>
          </div>
          <DollarSign className="w-12 h-12 opacity-30" />
        </motion.div>

        <motion.div
          className="bg-purple-500 text-white rounded-2xl p-6 shadow-lg flex items-center justify-between"
          whileHover={{ scale: 1.03 }}
          transition={{ type: "spring", stiffness: 400, damping: 10 }}
        >
          <div>
            <p className="text-sm font-medium opacity-80">Asesores Activos</p>
            <h3 className="text-4xl font-bold mt-1">{salesByAdvisor.length}</h3>
          </div>
          <Users className="w-12 h-12 opacity-30" />
        </motion.div>

        <motion.div
          className="bg-emerald-500 text-white rounded-2xl p-6 shadow-lg flex items-center justify-between"
          whileHover={{ scale: 1.03 }}
          transition={{ type: "spring", stiffness: 400, damping: 10 }}
        >
          <div>
            <p className="text-sm font-medium opacity-80">Zonas de Venta</p>
            <h3 className="text-4xl font-bold mt-1">{salesByZone.length}</h3>
          </div>
          <MapPin className="w-12 h-12 opacity-30" />
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          className="bg-gray-50/80 border border-gray-200 rounded-2xl p-6 shadow-md"
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <h3 className="text-xl font-bold text-gray-800 mb-4">Ventas por Asesor</h3>
          <ul className="space-y-3">
            {salesByAdvisor.length > 0 ? (
              salesByAdvisor.map((advisor, index) => (
                <motion.li
                  key={advisor.name}
                  className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <span className="font-medium text-gray-700">{advisor.name}</span>
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold">
                    {advisor.count} ventas
                  </span>
                </motion.li>
              ))
            ) : (
              <p className="text-gray-500">No hay ventas registradas para asesores en este período.</p>
            )}
          </ul>
        </motion.div>

        <motion.div
          className="bg-gray-50/80 border border-gray-200 rounded-2xl p-6 shadow-md"
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <h3 className="text-xl font-bold text-gray-800 mb-4">Ventas por Zona</h3>
          <ul className="space-y-3">
            {salesByZone.length > 0 ? (
              salesByZone.map((zone, index) => (
                <motion.li
                  key={zone.name}
                  className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <span className="font-medium text-gray-700">{zone.name}</span>
                  <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-semibold">
                    {zone.count} ventas
                  </span>
                </motion.li>
              ))
            ) : (
              <p className="text-gray-500">No hay ventas registradas por zona en este período.</p>
            )}
          </ul>
        </motion.div>

        <motion.div
          className="bg-gray-50/80 border border-gray-200 rounded-2xl p-6 shadow-md lg:col-span-2"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <h3 className="text-xl font-bold text-gray-800 mb-4">Ventas por Tipo de Servicio</h3>
          <ul className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {salesByService.length > 0 ? (
              salesByService.map((service, index) => (
                <motion.li
                  key={service.type}
                  className="flex flex-col items-center justify-center bg-white p-4 rounded-xl shadow-sm border border-gray-100 text-center"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.07 }}
                >
                  <span className="font-medium text-gray-700 capitalize mb-1">{service.type}</span>
                  <span className="text-2xl font-bold text-emerald-700">{service.count}</span>
                  <span className="text-sm text-gray-500">ventas</span>
                </motion.li>
              ))
            ) : (
              <p className="text-gray-500 col-span-full">No hay ventas registradas por tipo de servicio en este período.</p>
            )}
          </ul>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Dashboard;