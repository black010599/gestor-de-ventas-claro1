import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '../utils/supabase';
import { UserPlus, Trash2, Edit, Save, X, Info, PlusCircle, MapPin, FileText, UserX, Users } from 'lucide-react';
import { exportToExcel } from '../utils/helpers';

const AdvisorManagement = ({ user }) => {
  const [advisors, setAdvisors] = useState([]);
  const [newAdvisorName, setNewAdvisorName] = useState('');
  const [newAdvisorUsername, setNewAdvisorUsername] = useState('');
  const [newAdvisorPassword, setNewAdvisorPassword] = useState('');
  const [editingAdvisorId, setEditingAdvisorId] = useState(null);
  const [editingAdvisorNotes, setEditingAdvisorNotes] = useState('');
  const [selectedAdvisor, setSelectedAdvisor] = useState(null);
  const [advisorSales, setAdvisorSales] = useState([]);
  const [salesZones, setSalesZones] = useState([]);
  const [newZoneName, setNewZoneName] = useState('');
  const [editingZoneId, setEditingZoneId] = useState(null);
  const [editingZoneName, setEditingZoneName] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchAdvisorsAndZones();
  }, []);

  const fetchAdvisorsAndZones = async () => {
    setLoading(true);
    setError('');
    try {
      const { data: advisorsData, error: advisorsError } = await supabase
        .from('advisors')
        .select('*, users(username, role)'); // Fetch user role as well
      if (advisorsError) throw advisorsError;
      setAdvisors(advisorsData);

      const { data: zonesData, error: zonesError } = await supabase
        .from('sales_zones')
        .select('*');
      if (zonesError) throw zonesError;
      setSalesZones(zonesData);

    } catch (err) {
      console.error('Error fetching advisors or zones:', err);
      setError('Error al cargar asesores o zonas: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddAdvisor = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    if (!newAdvisorName.trim() || !newAdvisorUsername.trim() || !newAdvisorPassword.trim()) {
      setError('Todos los campos del asesor son obligatorios.');
      return;
    }

    try {
      // 1. Crear el usuario en la tabla 'users'
      const { data: userData, error: userError } = await supabase
        .from('users')
        .insert([{ username: newAdvisorUsername, password: newAdvisorPassword, role: 'vendedor' }])
        .select()
        .single();

      if (userError) throw userError;

      // 2. Crear el asesor en la tabla 'advisors' usando el user_id
      const { data: advisorData, error: advisorError } = await supabase
        .from('advisors')
        .insert([{ name: newAdvisorName, user_id: userData.id }])
        .select('*, users(username, role)') // Fetch user role for immediate display
        .single();

      if (advisorError) throw advisorError;

      setAdvisors((prev) => [...prev, advisorData]);
      setNewAdvisorName('');
      setNewAdvisorUsername('');
      setNewAdvisorPassword('');
      setMessage('Asesor y usuario creados exitosamente.');
    } catch (err) {
      console.error('Error adding advisor:', err);
      setError('Error al agregar asesor: ' + err.message);
    }
  };

  const handleDeleteAdvisor = async (advisorId, userId) => {
    setError('');
    setMessage('');
    if (!window.confirm('¿Estás seguro de que quieres eliminar a este asesor y su usuario? Esta acción es irreversible.')) return;

    try {
      // Eliminar el asesor (esto debería disparar la eliminación en 'users' si hay CASCADE)
      const { error: advisorError } = await supabase
        .from('advisors')
        .delete()
        .eq('id', advisorId);

      if (advisorError) throw advisorError;

      // También eliminar el usuario asociado, por si acaso el CASCADE no funciona como se espera o para mayor claridad
      const { error: userError } = await supabase
        .from('users')
        .delete()
        .eq('id', userId);

      if (userError) throw userError;

      setAdvisors((prev) => prev.filter((a) => a.id !== advisorId));
      setMessage('Asesor y usuario eliminados exitosamente.');
      if (selectedAdvisor?.id === advisorId) setSelectedAdvisor(null); // Deseleccionar si es el que estaba viendo
    } catch (err) {
      console.error('Error deleting advisor:', err);
      setError('Error al eliminar asesor: ' + err.message);
    }
  };

  const handleToggleUserAccess = async (userId, currentRole) => {
    setError('');
    setMessage('');
    // Toggle between 'vendedor' and 'disabled'
    const newRole = currentRole === 'vendedor' ? 'disabled' : 'vendedor'; 
    const confirmMessage = newRole === 'disabled' 
      ? '¿Estás seguro de que quieres deshabilitar el acceso a este usuario? No podrá iniciar sesión.'
      : '¿Estás seguro de que quieres habilitar el acceso a este usuario?';

    if (!window.confirm(confirmMessage)) return;

    try {
      const { error: updateError } = await supabase
        .from('users')
        .update({ role: newRole })
        .eq('id', userId);

      if (updateError) throw updateError;

      setAdvisors((prev) =>
        prev.map((a) => (a.user_id === userId ? { ...a, users: { ...a.users, role: newRole } } : a))
      );
      setMessage(`Acceso del usuario ${newRole === 'disabled' ? 'deshabilitado' : 'habilitado'} exitosamente.`);
    } catch (err) {
      console.error('Error toggling user access:', err);
      setError('Error al cambiar el acceso del usuario: ' + err.message);
    }
  };

  const handleEditNotes = (advisor) => {
    setEditingAdvisorId(advisor.id);
    setEditingAdvisorNotes(advisor.notes || '');
  };

  const handleSaveNotes = async (advisorId) => {
    setError('');
    setMessage('');
    try {
      const { error: updateError } = await supabase
        .from('advisors')
        .update({ notes: editingAdvisorNotes })
        .eq('id', advisorId);

      if (updateError) throw updateError;

      setAdvisors((prev) =>
        prev.map((a) => (a.id === advisorId ? { ...a, notes: editingAdvisorNotes } : a))
      );
      setEditingAdvisorId(null);
      setMessage('Notas actualizadas exitosamente.');
    } catch (err) {
      console.error('Error saving notes:', err);
      setError('Error al guardar notas: ' + err.message);
    }
  };

  const handleViewAdvisorDetails = async (advisor) => {
    setSelectedAdvisor(advisor);
    setError('');
    setMessage('');
    try {
      const { data: salesData, error: salesError } = await supabase
        .from('sales')
        .select(`
          client_name, client_id_card, client_phone, province, canton, district,
          installation_order, form_number, sale_date, contracted_plan, service_type,
          sales_zones (name)
        `)
        .eq('advisor_id', advisor.id)
        .order('sale_date', { ascending: false });

      if (salesError) throw salesError;
      setAdvisorSales(salesData);
    } catch (err) {
      console.error('Error fetching advisor sales:', err);
      setError('Error al cargar ventas del asesor: ' + err.message);
    }
  };

  const handleAddZone = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    if (!newZoneName.trim()) {
      setError('El nombre de la zona es obligatorio.');
      return;
    }
    try {
      const { data, error: zoneError } = await supabase
        .from('sales_zones')
        .insert([{ name: newZoneName }])
        .select()
        .single();

      if (zoneError) throw zoneError;
      setSalesZones((prev) => [...prev, data]);
      setNewZoneName('');
      setMessage('Zona de venta agregada exitosamente.');
    } catch (err) {
      console.error('Error adding zone:', err);
      setError('Error al agregar zona: ' + err.message);
    }
  };

  const handleEditZone = (zone) => {
    setEditingZoneId(zone.id);
    setEditingZoneName(zone.name);
  };

  const handleSaveZone = async (zoneId) => {
    setError('');
    setMessage('');
    if (!editingZoneName.trim()) {
      setError('El nombre de la zona no puede estar vacío.');
      return;
    }
    try {
      const { error: updateError } = await supabase
        .from('sales_zones')
        .update({ name: editingZoneName })
        .eq('id', zoneId);

      if (updateError) throw updateError;

      setSalesZones((prev) =>
        prev.map((z) => (z.id === zoneId ? { ...z, name: editingZoneName } : z))
      );
      setEditingZoneId(null);
      setMessage('Zona de venta actualizada exitosamente.');
    } catch (err) {
      console.error('Error saving zone:', err);
      setError('Error al guardar zona: ' + err.message);
    }
  };

  const handleDeleteZone = async (zoneId) => {
    setError('');
    setMessage('');
    if (!window.confirm('¿Estás seguro de que quieres eliminar esta zona de venta?')) return;
    try {
      const { error: deleteError } = await supabase
        .from('sales_zones')
        .delete()
        .eq('id', zoneId);

      if (deleteError) throw deleteError;
      setSalesZones((prev) => prev.filter((z) => z.id !== zoneId));
      setMessage('Zona de venta eliminada exitosamente.');
    } catch (err) {
      console.error('Error deleting zone:', err);
      setError('Error al eliminar zona: ' + err.message);
    }
  };

  const handleExportAdvisorSales = (advisor) => {
    if (!advisorSales.length) {
      setError('No hay ventas para exportar para este asesor.');
      return;
    }
    const formattedData = advisorSales.map(sale => ({
      'Nombre Cliente': sale.client_name,
      'Cédula Cliente': sale.client_id_card,
      'Teléfono Cliente': sale.client_phone,
      'Provincia': sale.province,
      'Cantón': sale.canton,
      'Distrito': sale.district,
      'Orden de Instalación': sale.installation_order,
      'Número de Formulario': sale.form_number,
      'Fecha de Venta': sale.sale_date,
      'Plan Contratado': sale.contracted_plan,
      'Tipo de Servicio': sale.service_type,
      'Zona de Venta': sale.sales_zones?.name || 'Desconocida',
    }));
    exportToExcel(formattedData, `Ventas_${advisor.name}`);
  };

  if (loading) return <div className="text-center text-gray-600">Cargando gestión de asesores...</div>;
  if (error) return <div className="text-center text-red-600">{error}</div>;

  return (
    <motion.div
      className="p-4 sm:p-8 bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl w-full max-w-full mx-auto" // Adjusted for responsiveness
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
        <Users className="w-6 h-6 sm:w-7 sm:h-7 text-blue-600" /> Gestión de Asesores
      </h2>

      {error && (
        <motion.p
          className="text-red-600 text-sm text-center bg-red-100 border border-red-200 rounded-lg p-3 mb-4"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {error}
        </motion.p>
      )}
      {message && (
        <motion.p
          className="text-green-600 text-sm text-center bg-green-100 border border-green-200 rounded-lg p-3 mb-4"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {message}
        </motion.p>
      )}

      {/* Sección para agregar Asesor */}
      <motion.div
        className="bg-gray-50/80 border border-gray-200 rounded-2xl p-4 sm:p-6 shadow-md mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
      >
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
          <UserPlus className="w-5 h-5 text-blue-500" /> Agregar Nuevo Asesor
        </h3>
        <form onSubmit={handleAddAdvisor} className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="text"
            placeholder="Nombre del Asesor"
            value={newAdvisorName}
            onChange={(e) => setNewAdvisorName(e.target.value)}
            className="px-3 py-2 sm:px-4 sm:py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            required
          />
          <input
            type="text"
            placeholder="Usuario (para login)"
            value={newAdvisorUsername}
            onChange={(e) => setNewAdvisorUsername(e.target.value)}
            className="px-3 py-2 sm:px-4 sm:py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            required
          />
          <input
            type="password"
            placeholder="Contraseña (para login)"
            value={newAdvisorPassword}
            onChange={(e) => setNewAdvisorPassword(e.target.value)}
            className="px-3 py-2 sm:px-4 sm:py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            required
          />
          <motion.button
            type="submit"
            className="md:col-span-3 bg-blue-500 text-white px-4 py-2 sm:px-5 sm:py-2 rounded-xl font-semibold shadow-md hover:bg-blue-600 transition-all duration-300 flex items-center justify-center gap-2 text-sm sm:text-base"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <PlusCircle className="w-4 h-4 sm:w-5 sm:h-5" />
            Agregar Asesor
          </motion.button>
        </form>
      </motion.div>

      {/* Lista de Asesores */}
      <motion.div
        className="bg-gray-50/80 border border-gray-200 rounded-2xl p-4 sm:p-6 shadow-md mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4">Lista de Asesores</h3>
        <ul className="space-y-3">
          <AnimatePresence>
            {advisors.map((advisor) => (
              <motion.li
                key={advisor.id}
                className="bg-white p-3 sm:p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex-1 min-w-0"> {/* Added min-w-0 for better wrapping */}
                  <p className="font-semibold text-gray-800 text-sm sm:text-base">{advisor.name} <span className="text-xs sm:text-sm text-gray-500">({advisor.users?.username} - {advisor.users?.role === 'disabled' ? 'Acceso Deshabilitado' : advisor.users?.role})</span></p>
                  {editingAdvisorId === advisor.id ? (
                    <textarea
                      value={editingAdvisorNotes}
                      onChange={(e) => setEditingAdvisorNotes(e.target.value)}
                      className="w-full mt-2 px-3 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500/30 text-xs sm:text-sm"
                      rows="2"
                      placeholder="Notas sobre el asesor..."
                    />
                  ) : (
                    <p className="text-gray-600 text-xs sm:text-sm mt-1 break-words">{advisor.notes || 'Sin notas'}</p>
                  )}
                </div>
                <div className="flex gap-2 flex-wrap justify-end sm:justify-start"> {/* Adjusted justify for small screens */}
                  {editingAdvisorId === advisor.id ? (
                    <>
                      <motion.button
                        onClick={() => handleSaveNotes(advisor.id)}
                        className="bg-green-500 text-white p-2 rounded-full hover:bg-green-600 transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Save className="w-4 h-4" />
                      </motion.button>
                      <motion.button
                        onClick={() => setEditingAdvisorId(null)}
                        className="bg-gray-400 text-white p-2 rounded-full hover:bg-gray-500 transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <X className="w-4 h-4" />
                      </motion.button>
                    </>
                  ) : (
                    <motion.button
                      onClick={() => handleEditNotes(advisor)}
                      className="bg-yellow-500 text-white p-2 rounded-full hover:bg-yellow-600 transition-colors"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Edit className="w-4 h-4" />
                    </motion.button>
                  )}
                  <motion.button
                    onClick={() => handleViewAdvisorDetails(advisor)}
                    className="bg-indigo-500 text-white p-2 rounded-full hover:bg-indigo-600 transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Info className="w-4 h-4" />
                  </motion.button>
                  <motion.button
                    onClick={() => handleToggleUserAccess(advisor.user_id, advisor.users?.role)}
                    className={`${advisor.users?.role === 'disabled' ? 'bg-green-500' : 'bg-orange-500'} text-white p-2 rounded-full hover:${advisor.users?.role === 'disabled' ? 'bg-green-600' : 'bg-orange-600'} transition-colors`}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    {advisor.users?.role === 'disabled' ? <UserPlus className="w-4 h-4" /> : <UserX className="w-4 h-4" />}
                  </motion.button>
                  <motion.button
                    onClick={() => handleDeleteAdvisor(advisor.id, advisor.user_id)}
                    className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </motion.button>
                </div>
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>
      </motion.div>

      {/* Detalles del Asesor Seleccionado */}
      <AnimatePresence>
        {selectedAdvisor && (
          <motion.div
            className="bg-gray-50/80 border border-gray-200 rounded-2xl p-4 sm:p-6 shadow-md mb-8"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg sm:text-xl font-bold text-gray-800">
                Ventas de {selectedAdvisor.name}
              </h3>
              <div className="flex gap-2">
                <motion.button
                  onClick={() => handleExportAdvisorSales(selectedAdvisor)}
                  className="bg-green-500 text-white px-3 py-1 sm:px-4 sm:py-2 rounded-xl font-semibold shadow-md hover:bg-green-600 transition-all duration-300 flex items-center gap-2 text-xs sm:text-sm"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <FileText className="w-4 h-4" />
                  Exportar Ventas
                </motion.button>
                <motion.button
                  onClick={() => setSelectedAdvisor(null)}
                  className="bg-gray-400 text-white p-2 rounded-full hover:bg-gray-500 transition-colors"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <X className="w-4 h-4" />
                </motion.button>
              </div>
            </div>
            {advisorSales.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white rounded-lg shadow-sm text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-gray-100 text-gray-600 uppercase text-left leading-normal">
                      <th className="py-2 px-3 sm:py-3 sm:px-6">Cliente</th>
                      <th className="py-2 px-3 sm:py-3 sm:px-6">Plan</th>
                      <th className="py-2 px-3 sm:py-3 sm:px-6">Fecha</th>
                      <th className="py-2 px-3 sm:py-3 sm:px-6">Zona</th>
                    </tr>
                  </thead>
                  <tbody className="text-gray-700 font-light">
                    {advisorSales.map((sale, index) => (
                      <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="py-2 px-3 sm:py-3 sm:px-6 whitespace-nowrap">{sale.client_name}</td>
                        <td className="py-2 px-3 sm:py-3 sm:px-6">{sale.contracted_plan}</td>
                        <td className="py-2 px-3 sm:py-3 sm:px-6">{sale.sale_date}</td>
                        <td className="py-2 px-3 sm:py-3 sm:px-6">{sale.sales_zones?.name || 'N/A'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500 text-sm">Este asesor aún no tiene ventas registradas.</p>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sección para gestionar Zonas de Venta */}
      <motion.div
        className="bg-gray-50/80 border border-gray-200 rounded-2xl p-4 sm:p-6 shadow-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
      >
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
          <MapPin className="w-5 h-5 text-blue-500" /> Gestión de Zonas de Venta
        </h3>
        <form onSubmit={handleAddZone} className="flex flex-col sm:flex-row gap-3 mb-6">
          <input
            type="text"
            placeholder="Nueva Zona de Venta"
            value={newZoneName}
            onChange={(e) => setNewZoneName(e.target.value)}
            className="flex-1 px-3 py-2 sm:px-4 sm:py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            required
          />
          <motion.button
            type="submit"
            className="bg-blue-500 text-white px-4 py-2 sm:px-5 sm:py-2 rounded-xl font-semibold shadow-md hover:bg-blue-600 transition-all duration-300 flex items-center justify-center gap-2 text-sm sm:text-base"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <PlusCircle className="w-4 h-4 sm:w-5 sm:h-5" />
            Agregar Zona
          </motion.button>
        </form>

        <ul className="space-y-3">
          <AnimatePresence>
            {salesZones.map((zone) => (
              <motion.li
                key={zone.id}
                className="bg-white p-3 sm:p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                {editingZoneId === zone.id ? (
                  <input
                    type="text"
                    value={editingZoneName}
                    onChange={(e) => setEditingZoneName(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500/30 text-sm"
                  />
                ) : (
                  <span className="font-medium text-gray-800 text-sm sm:text-base">{zone.name}</span>
                )}
                <div className="flex gap-2 flex-wrap justify-end sm:justify-start">
                  {editingZoneId === zone.id ? (
                    <>
                      <motion.button
                        onClick={() => handleSaveZone(zone.id)}
                        className="bg-green-500 text-white p-2 rounded-full hover:bg-green-600 transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Save className="w-4 h-4" />
                      </motion.button>
                      <motion.button
                        onClick={() => setEditingZoneId(null)}
                        className="bg-gray-400 text-white p-2 rounded-full hover:bg-gray-500 transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <X className="w-4 h-4" />
                      </motion.button>
                    </>
                  ) : (
                    <motion.button
                      onClick={() => handleEditZone(zone)}
                      className="bg-yellow-500 text-white p-2 rounded-full hover:bg-yellow-600 transition-colors"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Edit className="w-4 h-4" />
                    </motion.button>
                  )}
                  <motion.button
                    onClick={() => handleDeleteZone(zone.id)}
                    className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </motion.button>
                </div>
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>
      </motion.div>
    </motion.div>
  );
};

export default AdvisorManagement;