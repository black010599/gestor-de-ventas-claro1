import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '../utils/supabase';
import { Search, Filter, XCircle, FileText, Edit, Trash2, Save, X, Share2 } from 'lucide-react'; // Import Share2 icon
import { exportToExcel } from '../utils/helpers';
// Removed jspdf and jspdf-autotable imports

const SalesList = ({ user, showNotification }) => {
  const [sales, setSales] = useState([]);
  const [advisors, setAdvisors] = useState([]);
  const [salesZones, setSalesZones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAdvisor, setFilterAdvisor] = useState('');
  const [filterZone, setFilterZone] = useState('');
  const [filterServiceType, setFilterServiceType] = useState('');
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');

  // Dashboard data for export
  const [dashboardDataForExport, setDashboardDataForExport] = useState(null);

  // Editing state
  const [editingSaleData, setEditingSaleData] = useState(null);

  useEffect(() => {
    fetchSalesAndFilters();
    fetchDashboardDataForExport(); // Fetch dashboard data when component mounts or filters change
  }, [searchTerm, filterAdvisor, filterZone, filterServiceType, filterStartDate, filterEndDate]);

  const fetchSalesAndFilters = async () => {
    setLoading(true);
    setError('');
    try {
      // Fetch advisors and zones for filter dropdowns
      const { data: advisorsData, error: advisorsError } = await supabase
        .from('advisors')
        .select('*');
      if (advisorsError) throw advisorsError;
      setAdvisors(advisorsData);

      const { data: zonesData, error: zonesError } = await supabase
        .from('sales_zones')
        .select('*');
      if (zonesError) throw zonesError;
      setSalesZones(zonesData);

      // Fetch sales with filters
      let query = supabase.from('sales').select(`
        *,
        advisors (name),
        sales_zones (name)
      `);

      // No role-based filtering here, all users see all sales
      // if (user.role === 'vendedor') {
      //   query = query.eq('advisor_id', user.advisor_id);
      // }

      if (searchTerm) {
        query = query.or(`client_name.ilike.%${searchTerm}%,client_id_card.ilike.%${searchTerm}%,contracted_plan.ilike.%${searchTerm}%`);
      }
      if (filterAdvisor) { // All users can filter by advisor
        query = query.eq('advisor_id', filterAdvisor);
      }
      if (filterZone) {
        query = query.eq('sales_zone_id', filterZone);
      }
      if (filterServiceType) {
        query = query.eq('service_type', filterServiceType);
      }
      if (filterStartDate) {
        query = query.gte('sale_date', filterStartDate);
      }
      if (filterEndDate) {
        query = query.lte('sale_date', filterEndDate);
      }

      query = query.order('sale_date', { ascending: false });

      const { data: salesData, error: salesError } = await query;
      if (salesError) throw salesError;
      setSales(salesData);

    } catch (err) {
      console.error('Error fetching sales or filters:', err);
      setError('Error al cargar la lista de ventas: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchDashboardDataForExport = async () => {
    try {
      let query = supabase.from('sales').select(`
        *,
        advisors (name),
        sales_zones (name)
      `);

      const today = new Date();
      let start = new Date();
      let end = new Date();

      // Always fetch for 'day' for the dashboard summary in Excel
      start.setHours(0, 0, 0, 0);
      end.setHours(23, 59, 59, 999);
      
      query = query.gte('sale_date', start.toISOString().split('T')[0]);
      query = query.lte('sale_date', end.toISOString().split('T')[0]);

      const { data: salesData, error: salesError } = await query;

      if (salesError) throw salesError;

      const totalSales = salesData.length;

      const advisorSales = salesData.reduce((acc, sale) => {
        const advisorName = sale.advisors?.name || 'Desconocido';
        acc[advisorName] = (acc[advisorName] || 0) + 1;
        return acc;
      }, {});
      const salesByAdvisor = Object.entries(advisorSales).map(([name, count]) => ({ name, count }));

      const zoneSales = salesData.reduce((acc, sale) => {
        const zoneName = sale.sales_zones?.name || 'Desconocida';
        acc[zoneName] = (acc[zoneName] || 0) + 1;
        return acc;
      }, {});
      const salesByZone = Object.entries(zoneSales).map(([name, count]) => ({ name, count }));

      const serviceSales = salesData.reduce((acc, sale) => {
        const serviceType = sale.service_type || 'Desconocido';
        acc[serviceType] = (acc[serviceType] || 0) + 1;
        return acc;
      }, {});
      const salesByService = Object.entries(serviceSales).map(([type, count]) => ({ type, count }));

      setDashboardDataForExport({
        totalSales,
        salesByAdvisor,
        salesByZone,
        salesByService
      });

    } catch (err) {
      console.error('Error fetching dashboard data for export:', err.message);
      // Don't set global error, just log it
    }
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setFilterAdvisor('');
    setFilterZone('');
    setFilterServiceType('');
    setFilterStartDate('');
    setFilterEndDate('');
    showNotification('Filtros limpiados.', 'info');
  };

  const handleExportSales = (format) => {
    if (!sales.length) {
      showNotification('No hay ventas para exportar con los filtros actuales.', 'info');
      return;
    }

    const formattedData = sales.map(sale => ({
      'Nombre Cliente': sale.client_name,
      'Cédula Cliente': sale.client_id_card,
      'Teléfono Cliente': sale.client_phone,
      'Provincia': sale.province,
      'Cantón': sale.canton,
      'Distrito': sale.district,
      'Orden de Instalación': sale.installation_order,
      'Número de Formulario': sale.form_number,
      'Fecha de Venta': sale.sale_date,
      'Plan Contratado': sale.contracted_plan,
      'Tipo de Servicio': sale.service_type,
      'Vendedor': sale.advisors?.name || 'Desconocido',
      'Zona de Venta': sale.sales_zones?.name || 'Desconocida',
      'SIM': sale.sim || 'N/A'
    }));

    if (format === 'excel') {
      exportToExcel(formattedData, 'Lista_Ventas_Filtradas', dashboardDataForExport);
      showNotification('Ventas exportadas a Excel.', 'success');
    } 
    // Removed PDF export logic
  };

  const handleEditSale = (sale) => {
    // Ensure sim is not undefined, set to empty string if null/undefined
    setEditingSaleData({ ...sale, sim: sale.sim || '' });
  };

  const handleSaveEdit = async () => {
    if (!editingSaleData) return;

    try {
      const { id, advisors, sales_zones, ...updates } = editingSaleData; // Destructure to remove joined data
      
      // Ensure service_type is valid
      const validServiceTypes = ['internet', 'doble play', 'full claro', '1 play'];
      if (!validServiceTypes.includes(updates.service_type)) {
        showNotification('Tipo de servicio inválido.', 'error');
        return;
      }

      const { data: updatedSale, error: updateError } = await supabase
        .from('sales')
        .update(updates)
        .eq('id', id)
        .select(`
          *,
          advisors (name),
          sales_zones (name)
        `) // Re-fetch with joined data to update state correctly
        .single();

      if (updateError) throw updateError;

      setSales(prevSales => prevSales.map(sale => 
        sale.id === id ? updatedSale : sale
      ));
      setEditingSaleData(null);
      showNotification('Venta actualizada exitosamente.', 'success');
    } catch (err) {
      console.error('Error updating sale:', err.message);
      showNotification('Error al actualizar la venta: ' + err.message, 'error');
    }
  };

  const handleDeleteSale = async (saleId) => {
    if (!window.confirm('¿Estás seguro de que quieres eliminar esta venta? Esta acción es irreversible.')) {
      return;
    }
    try {
      const { error: deleteError } = await supabase
        .from('sales')
        .delete()
        .eq('id', saleId);

      if (deleteError) throw deleteError;

      setSales(prevSales => prevSales.filter(sale => sale.id !== saleId));
      showNotification('Venta eliminada exitosamente.', 'success');
    } catch (err) {
      console.error('Error deleting sale:', err.message);
      showNotification('Error al eliminar la venta: ' + err.message, 'error');
    }
  };

  const handleShareOnWhatsApp = (sale) => {
    const message = `¡Nueva Venta Registrada! 🎉\n\n` +
                    `Cliente: ${sale.client_name}\n` +
                    `Cédula: ${sale.client_id_card}\n` +
                    `Teléfono: ${sale.client_phone}\n` +
                    `Plan: ${sale.contracted_plan} (${sale.service_type})\n` +
                    `Vendedor: ${sale.advisors?.name || 'N/A'}\n` +
                    `Zona: ${sale.sales_zones?.name || 'N/A'}\n` +
                    `Fecha: ${sale.sale_date}\n` +
                    `Orden de Instalación: ${sale.installation_order}\n` +
                    `Formulario: ${sale.form_number}\n` +
                    `Provincia: ${sale.province}, Cantón: ${sale.canton}, Distrito: ${sale.district}\n` +
                    `SIM: ${sale.sim || 'N/A'}\n\n` +
                    `¡Gran trabajo! 🚀`;
    
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    showNotification('Venta compartida por WhatsApp.', 'info');
  };

  if (loading) return <div className="text-center text-gray-600">Cargando lista de ventas...</div>;
  if (error) return <div className="text-center text-red-600">{error}</div>;

  return (
    <motion.div
      className="p-8 bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
        <Filter className="w-7 h-7 text-blue-600" /> Lista de Ventas
      </h2>

      {/* Filters Section */}
      <motion.div
        className="bg-gray-50/80 border border-gray-200 rounded-2xl p-6 shadow-md mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
      >
        <h3 className="text-xl font-bold text-gray-800 mb-4">Filtros de Búsqueda</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
          <input
            type="text"
            placeholder="Buscar por cliente, cédula, plan..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
          />
          <select
            value={filterAdvisor}
            onChange={(e) => setFilterAdvisor(e.target.value)}
            className="px-4 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 bg-white"
          >
            <option value="">Todos los Vendedores</option>
            {advisors.map(advisor => (
              <option key={advisor.id} value={advisor.id}>{advisor.name}</option>
            ))}
          </select>
          <select
            value={filterZone}
            onChange={(e) => setFilterZone(e.target.value)}
            className="px-4 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 bg-white"
          >
            <option value="">Todas las Zonas</option>
            {salesZones.map(zone => (
              <option key={zone.id} value={zone.id}>{zone.name}</option>
            ))}
          </select>
          <select
            value={filterServiceType}
            onChange={(e) => setFilterServiceType(e.target.value)}
            className="px-4 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30 bg-white"
          >
            <option value="">Todos los Servicios</option>
            <option value="internet">Internet</option>
            <option value="doble play">Doble Play</option>
            <option value="full claro">Full Claro</option>
            <option value="1 play">1 Play</option>
          </select>
          <input
            type="date"
            placeholder="Fecha Inicio"
            value={filterStartDate}
            onChange={(e) => setFilterStartDate(e.target.value)}
            className="px-4 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
          />
          <input
            type="date"
            placeholder="Fecha Fin"
            value={filterEndDate}
            onChange={(e) => setFilterEndDate(e.target.value)}
            className="px-4 py-2 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
          />
        </div>
        <div className="flex justify-end gap-3">
          <motion.button
            onClick={handleClearFilters}
            className="bg-gray-400 text-white px-5 py-2 rounded-xl font-semibold shadow-md hover:bg-gray-500 transition-all duration-300 flex items-center gap-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <XCircle className="w-5 h-5" />
            Limpiar Filtros
          </motion.button>
          <motion.button
            onClick={() => handleExportSales('excel')}
            className="bg-green-500 text-white px-5 py-2 rounded-xl font-semibold shadow-md hover:bg-green-600 transition-all duration-300 flex items-center gap-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <FileText className="w-5 h-5" />
            Exportar a Excel
          </motion.button>
          {/* Removed PDF export button */}
        </div>
      </motion.div>

      {/* Sales Table */}
      <div className="overflow-x-auto">
        {sales.length > 0 ? (
          <table className="min-w-full bg-white rounded-lg shadow-sm">
            <thead>
              <tr className="bg-gray-100 text-gray-600 uppercase text-sm leading-normal">
                <th className="py-3 px-6 text-left">Cliente</th>
                <th className="py-3 px-6 text-left">Cédula</th>
                <th className="py-3 px-6 text-left">Teléfono</th>
                <th className="py-3 px-6 text-left">Plan</th>
                <th className="py-3 px-6 text-left">Servicio</th>
                <th className="py-3 px-6 text-left">Vendedor</th>
                <th className="py-3 px-6 text-left">Zona</th>
                <th className="py-3 px-6 text-left">Fecha</th>
                <th className="py-3 px-6 text-left">Orden Inst.</th>
                <th className="py-3 px-6 text-left">Form.</th>
                <th className="py-3 px-6 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="text-gray-700 text-sm font-light">
              <AnimatePresence>
                {sales.map((sale) => (
                  <motion.tr
                    key={sale.id}
                    className="border-b border-gray-200 hover:bg-gray-50"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                  >
                    <td className="py-3 px-6 text-left whitespace-nowrap">{sale.client_name}</td>
                    <td className="py-3 px-6 text-left">{sale.client_id_card}</td>
                    <td className="py-3 px-6 text-left">{sale.client_phone}</td>
                    <td className="py-3 px-6 text-left">{sale.contracted_plan}</td>
                    <td className="py-3 px-6 text-left capitalize">{sale.service_type}</td>
                    <td className="py-3 px-6 text-left">{sale.advisors?.name || 'N/A'}</td>
                    <td className="py-3 px-6 text-left">{sale.sales_zones?.name || 'N/A'}</td>
                    <td className="py-3 px-6 text-left">{sale.sale_date}</td>
                    <td className="py-3 px-6 text-left">{sale.installation_order}</td>
                    <td className="py-3 px-6 text-left">{sale.form_number}</td>
                    <td className="py-3 px-6 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <motion.button
                          onClick={() => handleEditSale(sale)}
                          className="text-blue-500 hover:text-blue-700"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Edit className="w-5 h-5" />
                        </motion.button>
                        <motion.button
                          onClick={() => handleDeleteSale(sale.id)}
                          className="text-red-500 hover:text-red-700"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Trash2 className="w-5 h-5" />
                        </motion.button>
                        <motion.button
                          onClick={() => handleShareOnWhatsApp(sale)}
                          className="text-green-500 hover:text-green-700"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                        >
                          <Share2 className="w-5 h-5" />
                        </motion.button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        ) : (
          <p className="text-center text-gray-500">No se encontraron ventas con los filtros aplicados.</p>
        )}
      </div>

      {/* Edit Sale Modal */}
      <AnimatePresence>
        {editingSaleData && (
          <motion.div
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white rounded-3xl p-8 shadow-xl w-full max-w-2xl"
              initial={{ scale: 0.9, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 50 }}
            >
              <h3 className="text-2xl font-bold text-gray-800 mb-6">Editar Venta</h3>
              <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Client Info */}
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Nombre Cliente:</label>
                  <input type="text" name="client_name" value={editingSaleData.client_name} onChange={(e) => setEditingSaleData({...editingSaleData, client_name: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Cédula:</label>
                  <input type="text" name="client_id_card" value={editingSaleData.client_id_card} onChange={(e) => setEditingSaleData({...editingSaleData, client_id_card: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Teléfono:</label>
                  <input type="text" name="client_phone" value={editingSaleData.client_phone} onChange={(e) => setEditingSaleData({...editingSaleData, client_phone: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Provincia:</label>
                  <input type="text" name="province" value={editingSaleData.province} onChange={(e) => setEditingSaleData({...editingSaleData, province: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Cantón:</label>
                  <input type="text" name="canton" value={editingSaleData.canton} onChange={(e) => setEditingSaleData({...editingSaleData, canton: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Distrito:</label>
                  <input type="text" name="district" value={editingSaleData.district} onChange={(e) => setEditingSaleData({...editingSaleData, district: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                {/* Sale Details */}
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Orden de Instalación:</label>
                  <input type="text" name="installation_order" value={editingSaleData.installation_order} onChange={(e) => setEditingSaleData({...editingSaleData, installation_order: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Número de Formulario:</label>
                  <input type="text" name="form_number" value={editingSaleData.form_number} onChange={(e) => setEditingSaleData({...editingSaleData, form_number: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Fecha de Venta:</label>
                  <input type="date" name="sale_date" value={editingSaleData.sale_date} onChange={(e) => setEditingSaleData({...editingSaleData, sale_date: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Plan Contratado:</label>
                  <input type="text" name="contracted_plan" value={editingSaleData.contracted_plan} onChange={(e) => setEditingSaleData({...editingSaleData, contracted_plan: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Tipo de Servicio:</label>
                  <select name="service_type" value={editingSaleData.service_type} onChange={(e) => setEditingSaleData({...editingSaleData, service_type: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300 bg-white">
                    <option value="internet">Internet</option>
                    <option value="doble play">Doble Play</option>
                    <option value="full claro">Full Claro</option>
                    <option value="1 play">1 Play</option>
                  </select>
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Vendedor:</label>
                  <select name="advisor_id" value={editingSaleData.advisor_id} onChange={(e) => setEditingSaleData({...editingSaleData, advisor_id: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300 bg-white">
                    {advisors.map(advisor => (
                      <option key={advisor.id} value={advisor.id}>{advisor.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">Zona de Venta:</label>
                  <select name="sales_zone_id" value={editingSaleData.sales_zone_id} onChange={(e) => setEditingSaleData({...editingSaleData, sales_zone_id: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300 bg-white">
                    {salesZones.map(zone => (
                      <option key={zone.id} value={zone.id}>{zone.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">SIM (Opcional):</label>
                  <input type="text" name="sim" value={editingSaleData.sim || ''} onChange={(e) => setEditingSaleData({...editingSaleData, sim: e.target.value})} className="w-full px-4 py-2 rounded-xl border border-gray-300" />
                </div>
              </form>
              <div className="flex justify-end gap-3 mt-6">
                <motion.button
                  onClick={() => setEditingSaleData(null)}
                  className="bg-gray-400 text-white px-5 py-2 rounded-xl font-semibold shadow-md hover:bg-gray-500 transition-all duration-300 flex items-center gap-2"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <X className="w-5 h-5" />
                  Cancelar
                </motion.button>
                <motion.button
                  onClick={handleSaveEdit}
                  className="bg-blue-500 text-white px-5 py-2 rounded-xl font-semibold shadow-md hover:bg-blue-600 transition-all duration-300 flex items-center gap-2"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Save className="w-5 h-5" />
                  Guardar Cambios
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default SalesList;