import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, XCircle, Info } from 'lucide-react';

const Notification = ({ message, type, onClose }) => {
  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => {
        onClose();
      }, 3000); // Notificación desaparece después de 3 segundos
      return () => clearTimeout(timer);
    }
  }, [message, onClose]);

  let bgColor = '';
  let textColor = '';
  let Icon = Info;

  switch (type) {
    case 'success':
      bgColor = 'bg-green-500';
      textColor = 'text-white';
      Icon = CheckCircle;
      break;
    case 'error':
      bgColor = 'bg-red-500';
      textColor = 'text-white';
      Icon = XCircle;
      break;
    case 'info':
    default:
      bgColor = 'bg-blue-500';
      textColor = 'text-white';
      Icon = Info;
      break;
  }

  return (
    <AnimatePresence>
      {message && (
        <motion.div
          initial={{ opacity: 0, y: -50, x: "-50%" }}
          animate={{ opacity: 1, y: 0, x: "-50%" }}
          exit={{ opacity: 0, y: -50, x: "-50%" }}
          transition={{ duration: 0.3 }}
          className={`fixed top-4 left-1/2 transform -translate-x-1/2 ${bgColor} ${textColor} px-6 py-3 rounded-xl shadow-lg flex items-center gap-3 z-50`}
        >
          <Icon className="w-5 h-5" />
          <span className="font-medium">{message}</span>
          <button onClick={onClose} className="ml-2 p-1 rounded-full hover:bg-white/20 transition-colors">
            <XCircle className="w-4 h-4" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default Notification;