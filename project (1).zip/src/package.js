on

{
    "dependencies": {
        "react": "^19.0.0",
        "react-dom": "^19.0.0",
        "react-scripts": "^5.0.0",
        "framer-motion": "latest",
        "lucide-react": "latest",
        "react-router-dom": "latest",
        "@supabase/supabase-js": "latest",
        "xlsx": "latest",
        "file-saver": "latest"
    },
    "main": "/index.js",
    "devDependencies": {}
}