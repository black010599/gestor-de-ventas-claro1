import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from './utils/supabase';
import Auth from './components/Auth';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import SaleForm from './components/SaleForm';
import AdvisorManagement from './components/AdvisorManagement';
import SalesList from './components/SalesList';
import Notification from './components/Notification'; // Import the Notification component

const App = () => {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard'); // Default tab
  const [notification, setNotification] = useState({ message: '', type: '' });

  useEffect(() => {
    // Check for existing session or user data (e.g., from local storage)
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUser(parsedUser);
    }
  }, []);

  const handleLogin = async (userData) => {
    // Check if user role is 'disabled'
    if (userData.role === 'disabled') {
      showNotification('Tu acceso ha sido deshabilitado. Contacta a tu supervisor.', 'error');
      return;
    }
    
    setUser(userData);
    localStorage.setItem('currentUser', JSON.stringify(userData));
    setActiveTab('dashboard'); // Redirect to dashboard after login
    showNotification('¡Bienvenido de nuevo!', 'success');
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
    showNotification('Sesión cerrada exitosamente.', 'info');
  };

  const showNotification = (message, type) => {
    setNotification({ message, type });
  };

  const clearNotification = () => {
    setNotification({ message: '', type: '' });
  };

  const renderContent = () => {
    if (!user) {
      return <Auth onLogin={handleLogin} />;
    }

    switch (activeTab) {
      case 'dashboard':
        return <Dashboard user={user} showNotification={showNotification} />;
      case 'add-sale':
        return <SaleForm user={user} showNotification={showNotification} />;
      case 'sales-list':
        return <SalesList user={user} showNotification={showNotification} />;
      case 'advisor-management':
        return user.role === 'supervisor' ? <AdvisorManagement user={user} showNotification={showNotification} /> : <p className="text-center text-red-600">Acceso denegado. Solo supervisores pueden gestionar asesores.</p>;
      default:
        return <Dashboard user={user} showNotification={showNotification} />;
    }
  };

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <Notification
        message={notification.message}
        type={notification.type}
        onClose={clearNotification}
      />
      <AnimatePresence mode="wait">
        {user && (
          <Sidebar
            user={user}
            onNavigate={setActiveTab}
            onLogout={handleLogout}
            activeTab={activeTab}
          />
        )}
      </AnimatePresence>
      <main className="flex-1 p-8 overflow-auto">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;