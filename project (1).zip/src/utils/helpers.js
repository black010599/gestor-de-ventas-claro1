import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

export const generateUniqueId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const exportToExcel = (data, fileName, dashboardData = null) => {
  const wb = XLSX.utils.book_new();

  // Sheet 1: Detailed Sales
  const wsDetailed = XLSX.utils.json_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, wsDetailed, 'Ventas Detalle');

  // Sheet 2: Summary by Service Type
  const salesByService = data.reduce((acc, sale) => {
    const serviceType = sale['Tipo de Servicio'] || 'Desconocido';
    acc[serviceType] = (acc[serviceType] || 0) + 1;
    return acc;
  }, {});

  const summaryData = Object.entries(salesByService).map(([type, count]) => ({
    'Tipo de Servicio': type,
    'Total Ventas': count
  }));
  const wsSummary = XLSX.utils.json_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Resumen por Servicio');

  // Sheet 3: Daily Dashboard Summary (if provided)
  if (dashboardData) {
    const dailySummary = [
      ['Resumen Diario de Ventas'],
      [], // Empty row for spacing
      ['Métrica', 'Valor'],
      ['Ventas Totales', dashboardData.totalSales],
      [],
      ['Ventas por Asesor'],
      ['Asesor', 'Ventas'],
      ...dashboardData.salesByAdvisor.map(a => [a.name, a.count]),
      [],
      ['Ventas por Zona'],
      ['Zona', 'Ventas'],
      ...dashboardData.salesByZone.map(z => [z.name, z.count]), // Added sales by zone
      [],
      ['Ventas por Tipo de Servicio'],
      ['Tipo de Servicio', 'Ventas'],
      ...dashboardData.salesByService.map(s => [s.type, s.count])
    ];
    const wsDailySummary = XLSX.utils.aoa_to_sheet(dailySummary);
    XLSX.utils.book_append_sheet(wb, wsDailySummary, 'Resumen Diario');
  }

  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const dataBlob = new Blob([excelBuffer], { type: 'application/octet-stream' });
  saveAs(dataBlob, fileName + '.xlsx');
};

export const parseSaleTemplate = (template) => {
  const data = {};
  const lines = template.split('\n');
  lines.forEach(line => {
    const [key, value] = line.split(':').map(s => s.trim());
    if (key && value) {
      switch (key) {
        case 'Nombre': data.client_name = value; break;
        case 'Cédula': data.client_id_card = value; break;
        case 'Teléfono': data.client_phone = value; break;
        case 'Provincia': data.province = value; break;
        case 'Cantón': data.canton = value; break;
        case 'Distrito': data.district = value; break;
        case 'Orden de instalación': data.installation_order = value; break;
        case 'Formulario': data.form_number = value; break;
        case 'Fecha de venta': data.sale_date = value; break;
        case 'Plan contratado': data.contracted_plan = value; break;
        case 'Vendedor': data.advisor_name = value; break;
        case 'Zonade venta': data.sales_zone_name = value; break;
        case 'Sim': data.sim = value; break; // Asumiendo que 'Sim' es un campo adicional
        default: break;
      }
    }
  });

  // Determinar service_type basado en contracted_plan
  if (data.contracted_plan) {
    const lowerPlan = data.contracted_plan.toLowerCase();
    if (lowerPlan.includes('internet') || lowerPlan.includes('1 play')) {
      data.service_type = 'internet';
    } else if (lowerPlan.includes('doble play')) {
      data.service_type = 'doble play';
    } else if (lowerPlan.includes('full claro')) {
      data.service_type = 'full claro';
    } else {
      data.service_type = '1 play'; // Default o si no se encuentra un tipo específico
    }
  }

  return data;
};