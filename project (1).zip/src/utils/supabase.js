import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://ghptljadspeaipqkctpc.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdocHRsamFkc3BlYWlwcWtjdHBjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5NjM3OTAsImV4cCI6MjA2NTUzOTc5MH0.6nM_H8Cz-F5LKXwUSq2lwqC_gE28IcRerQavhnzs24o';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);