CREATE OR REPLACE FUNCTION update_advisor_total_sales_on_sale_insert()
RETURNS TRIGGER AS $$
BEGIN
    -- Increment total_sales for the advisor
    UPDATE advisors
    SET total_sales = total_sales + 1
    WHERE id = NEW.advisor_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing trigger if it exists to avoid conflicts
DROP TRIGGER IF EXISTS update_advisor_total_sales_trigger ON sales;

CREATE TRIGGER update_advisor_total_sales_trigger
AFTER INSERT ON sales
FOR EACH ROW
EXECUTE FUNCTION update_advisor_total_sales_on_sale_insert();