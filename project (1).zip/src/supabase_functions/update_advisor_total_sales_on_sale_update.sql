CREATE OR REPLACE FUNCTION update_advisor_total_sales_on_sale_update()
RETURNS TRIGGER AS $$
BEGIN
    -- If advisor_id changes, update counts for both old and new advisors
    IF OLD.advisor_id IS DISTINCT FROM NEW.advisor_id THEN
        -- Decrement for old advisor
        UPDATE advisors
        SET total_sales = total_sales - 1
        WHERE id = OLD.advisor_id;

        -- Increment for new advisor
        UPDATE advisors
        SET total_sales = total_sales + 1
        WHERE id = NEW.advisor_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_advisor_total_sales_update_trigger
AFTER UPDATE OF advisor_id ON sales
FOR EACH ROW
EXECUTE FUNCTION update_advisor_total_sales_on_sale_update();