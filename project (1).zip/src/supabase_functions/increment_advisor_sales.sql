CREATE OR REPLACE FUNCTION increment_advisor_sales(advisor_id_param UUID)
RETURNS VOID AS $$
BEGIN
    UPDATE advisors
    SET total_sales = total_sales + 1
    WHERE id = advisor_id_param;
END;
$$ LANGUAGE plpgsql;