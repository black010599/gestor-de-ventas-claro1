CREATE OR REPLACE FUNCTION update_advisor_total_sales_on_sale_delete()
RETURNS TRIGGER AS $$
BEGIN
    -- Decrement total_sales for the advisor
    UPDATE advisors
    SET total_sales = total_sales - 1
    WHERE id = OLD.advisor_id;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_advisor_total_sales_delete_trigger
AFTER DELETE ON sales
FOR EACH ROW
EXECUTE FUNCTION update_advisor_total_sales_on_sale_delete();